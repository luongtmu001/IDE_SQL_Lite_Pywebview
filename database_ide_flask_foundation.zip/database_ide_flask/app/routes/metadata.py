from flask import Blueprint, jsonify, request
from app.routes._common import get_connection_manager, get_owner_session_id

metadata_bp = Blueprint("metadata", __name__)

def get_connection(connection_id):
    return get_connection_manager().get(
        get_owner_session_id(),
        connection_id,
    )

@metadata_bp.get("/<connection_id>/databases")
def databases(connection_id):
    try:
        connection = get_connection(connection_id)
        return jsonify(
            success=True,
            items=connection.metadata_service.list_databases(),
        )
    except PermissionError:
        return jsonify(success=False, error="Forbidden"), 403
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 400

@metadata_bp.get("/<connection_id>/schemas")
def schemas(connection_id):
    try:
        connection = get_connection(connection_id)
        return jsonify(
            success=True,
            items=connection.metadata_service.list_schemas(
                request.args.get("database")
            ),
        )
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 400

@metadata_bp.get("/<connection_id>/objects")
def objects(connection_id):
    try:
        connection = get_connection(connection_id)
        return jsonify(
            success=True,
            items=connection.metadata_service.list_objects(
                request.args.get("database"),
                request.args.get("schema"),
                request.args.get("type", "tables"),
            ),
        )
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 400

@metadata_bp.get("/<connection_id>/definition")
def definition(connection_id):
    try:
        connection = get_connection(connection_id)
        value = connection.metadata_service.get_object_definition(
            request.args.get("database"),
            request.args["schema"],
            request.args["name"],
            request.args["type"],
        )
        return jsonify(success=True, definition=value)
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 400
