from flask import Blueprint, jsonify, request
from app.routes._common import get_connection_manager, get_owner_session_id

query_bp = Blueprint("query", __name__)

@query_bp.post("/execute")
def execute():
    data = request.get_json(silent=True) or {}

    connection_id = data.get("connection_id")
    sql = data.get("sql", "")

    if not connection_id:
        return jsonify(success=False, error="connection_id is required"), 400

    if not sql.strip():
        return jsonify(success=False, error="SQL is empty"), 400

    try:
        connection = get_connection_manager().get(
            get_owner_session_id(),
            connection_id,
        )

        result = connection.query_service.execute(sql)
        return jsonify(result)

    except PermissionError:
        return jsonify(success=False, error="Forbidden"), 403
    except Exception as exc:
        return jsonify(success=False, error=str(exc)), 400
