class MetadataService:

    def __init__(self, connection_session):
        self.session = connection_session

    def _cache_key(self, *parts):
        return "::".join(
            "" if part is None else str(part)
            for part in parts
        )

    def list_databases(self):
        key = self._cache_key("databases")

        if key not in self.session.metadata_cache:
            with self.session.lock:
                self.session.metadata_cache[key] = (
                    self.session.adapter.list_databases()
                )

        return self.session.metadata_cache[key]

    def list_schemas(self, database=None):
        key = self._cache_key("schemas", database)

        if key not in self.session.metadata_cache:
            with self.session.lock:
                self.session.metadata_cache[key] = (
                    self.session.adapter.list_schemas(database)
                )

        return self.session.metadata_cache[key]

    def list_objects(self, database, schema, object_type):
        key = self._cache_key(
            "objects",
            database,
            schema,
            object_type,
        )

        if key not in self.session.metadata_cache:
            with self.session.lock:
                self.session.metadata_cache[key] = (
                    self.session.adapter.list_objects(
                        database,
                        schema,
                        object_type,
                    )
                )

        return self.session.metadata_cache[key]

    def get_object_definition(
        self,
        database,
        schema,
        name,
        object_type,
    ):
        with self.session.lock:
            return self.session.adapter.get_object_definition(
                database,
                schema,
                name,
                object_type,
            )

    def invalidate(self):
        with self.session.lock:
            self.session.metadata_cache.clear()
