class QueryService:

    def __init__(self, connection_session):
        self.session = connection_session

    def execute(self, sql, params=None):
        with self.session.lock:
            result = self.session.adapter.execute(
                sql,
                params,
            )
            self.session.touch()
            return result
