from threading import RLock
from uuid import uuid4

from app.database.factory import create_adapter
from app.models.connection_session import ConnectionSession
from app.services.metadata_service import MetadataService
from app.services.query_service import QueryService

class ConnectionManager:

    def __init__(self):
        self._connections = {}
        self._lock = RLock()

    def create(self, owner_session_id, config):
        adapter = create_adapter(config)
        adapter.connect()

        connection_id = f"conn_{uuid4().hex}"

        safe_config = {
            key: value
            for key, value in config.items()
            if key != "password"
        }

        connection = ConnectionSession(
            connection_id=connection_id,
            owner_session_id=owner_session_id,
            config=safe_config,
            adapter=adapter,
            metadata_service=None,
            query_service=None,
        )

        connection.metadata_service = MetadataService(connection)
        connection.query_service = QueryService(connection)

        with self._lock:
            self._connections[connection_id] = connection

        return connection

    def get(self, owner_session_id, connection_id):
        with self._lock:
            connection = self._connections.get(connection_id)

        if connection is None:
            raise KeyError("Connection not found")

        if connection.owner_session_id != owner_session_id:
            raise PermissionError(
                "Connection does not belong to this session"
            )

        connection.touch()
        return connection

    def list(self, owner_session_id):
        with self._lock:
            return [
                connection
                for connection in self._connections.values()
                if connection.owner_session_id == owner_session_id
            ]

    def close(self, owner_session_id, connection_id):
        connection = self.get(
            owner_session_id,
            connection_id,
        )

        with connection.lock:
            connection.adapter.close()

        with self._lock:
            self._connections.pop(connection_id, None)

    def close_all(self, owner_session_id):
        for connection in self.list(owner_session_id):
            self.close(
                owner_session_id,
                connection.connection_id,
            )
