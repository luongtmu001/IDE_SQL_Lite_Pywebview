from app.database.base import DatabaseAdapter

try:
    import pyodbc
except ImportError:
    pyodbc = None

class SqlServerAdapter(DatabaseAdapter):

    def connect(self):
        if pyodbc is None:
            raise RuntimeError("pyodbc is not installed")

        c = self.config
        driver = c.get(
            "driver",
            "ODBC Driver 18 for SQL Server",
        )
        server = c["server"]
        database = c.get("database") or "master"

        if c.get("trusted_connection"):
            conn_str = (
                f"DRIVER={{{driver}}};"
                f"SERVER={server};"
                f"DATABASE={database};"
                "Trusted_Connection=yes;"
                "TrustServerCertificate=yes;"
            )
        else:
            conn_str = (
                f"DRIVER={{{driver}}};"
                f"SERVER={server};"
                f"DATABASE={database};"
                f"UID={c['username']};"
                f"PWD={c['password']};"
                "TrustServerCertificate=yes;"
            )

        self.connection = pyodbc.connect(
            conn_str,
            timeout=int(c.get("timeout", 10)),
            autocommit=True,
        )

    def close(self):
        if self.connection:
            self.connection.close()
            self.connection = None

    def execute(self, sql, params=None):
        cursor = self.connection.cursor()

        try:
            cursor.execute(sql, params or ())

            columns = (
                [description[0] for description in cursor.description]
                if cursor.description
                else []
            )

            rows = (
                cursor.fetchmany(
                    int(self.config.get("max_rows", 1000))
                )
                if columns
                else []
            )

            return {
                "success": True,
                "columns": columns,
                "rows": [list(row) for row in rows],
                "row_count": len(rows),
                "message": "Command completed.",
            }

        finally:
            cursor.close()

    def list_databases(self):
        result = self.execute(
            "SELECT name, state_desc "
            "FROM sys.databases ORDER BY name"
        )

        return [
            {"name": row[0], "state": row[1]}
            for row in result["rows"]
        ]

    def list_schemas(self, database=None):
        result = self.execute(
            "SELECT name FROM sys.schemas ORDER BY name"
        )

        return [{"name": row[0]} for row in result["rows"]]

    def list_objects(self, database, schema, object_type):
        type_map = {
            "tables": "U",
            "views": "V",
            "procedures": "P",
            "functions": "FN",
        }

        sql = """
            SELECT s.name, o.name, o.object_id
            FROM sys.objects AS o
            JOIN sys.schemas AS s
              ON s.schema_id = o.schema_id
            WHERE s.name = ?
              AND o.type = ?
            ORDER BY o.name
        """

        result = self.execute(
            sql,
            (schema, type_map.get(object_type, "U")),
        )

        return [
            {
                "schema": row[0],
                "name": row[1],
                "id": row[2],
            }
            for row in result["rows"]
        ]

    def get_object_definition(
        self,
        database,
        schema,
        name,
        object_type,
    ):
        result = self.execute(
            """
            SELECT sm.definition
            FROM sys.sql_modules AS sm
            JOIN sys.objects AS o
              ON o.object_id = sm.object_id
            JOIN sys.schemas AS s
              ON s.schema_id = o.schema_id
            WHERE s.name = ?
              AND o.name = ?
            """,
            (schema, name),
        )

        return result["rows"][0][0] if result["rows"] else None
