from app.database.base import DatabaseAdapter

try:
    import psycopg
except ImportError:
    psycopg = None

class PostgreSqlAdapter(DatabaseAdapter):

    def connect(self):
        if psycopg is None:
            raise RuntimeError("psycopg is not installed")

        c = self.config

        self.connection = psycopg.connect(
            host=c["host"],
            port=int(c.get("port", 5432)),
            dbname=c.get("database", "postgres"),
            user=c["username"],
            password=c["password"],
            connect_timeout=int(c.get("timeout", 10)),
        )

        self.connection.autocommit = True

    def close(self):
        if self.connection:
            self.connection.close()
            self.connection = None

    def execute(self, sql, params=None):
        with self.connection.cursor() as cursor:
            cursor.execute(sql, params or ())

            columns = (
                [description.name for description in cursor.description]
                if cursor.description
                else []
            )

            rows = (
                cursor.fetchmany(
                    int(self.config.get("max_rows", 1000))
                )
                if columns
                else []
            )

            return {
                "success": True,
                "columns": columns,
                "rows": [list(row) for row in rows],
                "row_count": len(rows),
                "message": "Command completed.",
            }

    def list_databases(self):
        result = self.execute(
            """
            SELECT datname, datallowconn
            FROM pg_database
            WHERE datistemplate = false
            ORDER BY datname
            """
        )

        return [
            {
                "name": row[0],
                "allow_connection": row[1],
            }
            for row in result["rows"]
        ]

    def list_schemas(self, database=None):
        result = self.execute(
            """
            SELECT schema_name
            FROM information_schema.schemata
            WHERE schema_name NOT IN ('pg_toast')
            ORDER BY schema_name
            """
        )

        return [{"name": row[0]} for row in result["rows"]]

    def list_objects(self, database, schema, object_type):
        if object_type == "tables":
            sql = """
                SELECT table_schema, table_name
                FROM information_schema.tables
                WHERE table_schema = %s
                  AND table_type = 'BASE TABLE'
                ORDER BY table_name
            """
        elif object_type == "views":
            sql = """
                SELECT table_schema, table_name
                FROM information_schema.views
                WHERE table_schema = %s
                ORDER BY table_name
            """
        else:
            sql = """
                SELECT n.nspname, p.proname, p.oid
                FROM pg_proc AS p
                JOIN pg_namespace AS n
                  ON n.oid = p.pronamespace
                WHERE n.nspname = %s
                ORDER BY p.proname
            """

        result = self.execute(sql, (schema,))

        return [
            {
                "schema": row[0],
                "name": row[1],
                "id": row[2] if len(row) > 2 else None,
            }
            for row in result["rows"]
        ]

    def get_object_definition(
        self,
        database,
        schema,
        name,
        object_type,
    ):
        if object_type in {"functions", "procedures"}:
            result = self.execute(
                """
                SELECT pg_get_functiondef(p.oid)
                FROM pg_proc AS p
                JOIN pg_namespace AS n
                  ON n.oid = p.pronamespace
                WHERE n.nspname = %s
                  AND p.proname = %s
                LIMIT 1
                """,
                (schema, name),
            )

            return result["rows"][0][0] if result["rows"] else None

        if object_type == "views":
            result = self.execute(
                """
                SELECT
                    'CREATE OR REPLACE VIEW ' ||
                    quote_ident(schemaname) || '.' ||
                    quote_ident(viewname) || ' AS ' ||
                    definition
                FROM pg_views
                WHERE schemaname = %s
                  AND viewname = %s
                """,
                (schema, name),
            )

            return result["rows"][0][0] if result["rows"] else None

        return None
