from abc import ABC, abstractmethod
from typing import Any

class DatabaseAdapter(ABC):

    def __init__(self, config: dict[str, Any]):
        self.config = config
        self.connection = None

    @abstractmethod
    def connect(self):
        ...

    @abstractmethod
    def close(self):
        ...

    @abstractmethod
    def execute(self, sql: str, params=None):
        ...

    @abstractmethod
    def list_databases(self):
        ...

    @abstractmethod
    def list_schemas(self, database=None):
        ...

    @abstractmethod
    def list_objects(self, database, schema, object_type):
        ...

    @abstractmethod
    def get_object_definition(
        self,
        database,
        schema,
        name,
        object_type,
    ):
        ...
