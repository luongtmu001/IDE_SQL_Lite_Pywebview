import { api } from "./api.js";
import { state } from "./state.js";
import { renderConnections } from "./explorer.js";
import { createTab } from "./tabs.js";

export async function connectDatabase() {
    const type = prompt(
        "Database type: sqlserver / postgresql",
        "sqlserver"
    );

    if (!type) return;

    let config;

    if (type.toLowerCase() === "sqlserver") {
        config = {
            type: "sqlserver",
            server: prompt(
                "SQL Server server/instance",
                "localhost"
            ),
            database: prompt(
                "Database",
                "master"
            ),
            username: prompt(
                "Username",
                ""
            ),
            password: prompt(
                "Password",
                ""
            ),
            trusted_connection: false,
        };
    } else {
        config = {
            type: "postgresql",
            host: prompt(
                "PostgreSQL host",
                "localhost"
            ),
            port: Number(
                prompt("Port", "5432")
            ),
            database: prompt(
                "Database",
                "postgres"
            ),
            username: prompt(
                "Username",
                "postgres"
            ),
            password: prompt(
                "Password",
                ""
            ),
        };
    }

    try {
        const result = await api(
            "/api/connections",
            {
                method: "POST",
                body: JSON.stringify(config),
            }
        );

        state.connections.push(
            result.connection
        );

        renderConnections();

        createTab(
            result.connection.connection_id,
            result.connection.database
        );
    } catch (error) {
        alert(error.message);
    }
}

export async function loadExistingConnections() {
    const result = await api(
        "/api/connections"
    );

    state.connections = result.connections;
    renderConnections();
}
