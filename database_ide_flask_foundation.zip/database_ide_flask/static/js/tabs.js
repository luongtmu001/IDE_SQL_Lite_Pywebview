import { state, activeTab } from "./state.js";
import { escapeHtml } from "./utils.js";
import { renderEditor } from "./editor.js";

export function createTab(
    connectionId = null,
    database = null
) {
    const tab = {
        tabId: `tab_${crypto.randomUUID()}`,
        connectionId,
        database,
        name: `Query ${state.tabs.length + 1}`,
        sql: "",
        dirty: false,
    };

    state.tabs.push(tab);
    state.activeTabId = tab.tabId;

    renderTabs();
    renderEditor();
}

export function renderTabs() {
    const container = document.querySelector("#tabs");

    container.innerHTML = state.tabs.map(tab => `
        <div
            class="tab ${tab.tabId === state.activeTabId ? "active" : ""}"
            data-tab-id="${tab.tabId}"
        >
            ${escapeHtml(tab.name)}
            ${tab.dirty ? " ●" : ""}
        </div>
    `).join("");

    container.querySelectorAll("[data-tab-id]").forEach(node => {
        node.addEventListener("click", () => {
            state.activeTabId = node.dataset.tabId;
            renderTabs();
            renderEditor();

            const tab = activeTab();

            document.querySelector(
                "#statusConnection"
            ).textContent = tab?.connectionId
                ? `${tab.connectionId} / ${tab.database || "default"}`
                : "No connection";
        });
    });
}
