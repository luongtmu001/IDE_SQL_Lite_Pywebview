import {
    connectDatabase,
    loadExistingConnections,
} from "./connections.js";

import { createTab } from "./tabs.js";
import { toggleTheme } from "./theme.js";

document.querySelector(
    "#connectBtn"
).addEventListener(
    "click",
    connectDatabase
);

document.querySelector(
    "#newQuery"
).addEventListener(
    "click",
    () => createTab()
);

document.querySelector(
    "#themeBtn"
).addEventListener(
    "click",
    toggleTheme
);

document.querySelector(
    "#toggleExplorer"
).addEventListener(
    "click",
    () => {
        document.querySelector(
            "#explorer"
        ).classList.toggle("d-none");
    }
);

await loadExistingConnections();
createTab();
