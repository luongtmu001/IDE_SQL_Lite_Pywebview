export function toggleTheme() {
    const root = document.documentElement;
    const light = root.dataset.theme === "light";

    if (light) {
        root.dataset.theme = "dark";
        setDark();
    } else {
        root.dataset.theme = "light";
        setLight();
    }
}

function setDark() {
    set("--ide-bg", "#1e1e1e");
    set("--ide-sidebar", "#252526");
    set("--ide-editor", "#1e1e1e");
    set("--ide-panel", "#181818");
    set("--ide-border", "#3c3c3c");
    set("--ide-text", "#cccccc");
    set("--ide-muted", "#858585");
}

function setLight() {
    set("--ide-bg", "#ffffff");
    set("--ide-sidebar", "#f3f3f3");
    set("--ide-editor", "#ffffff");
    set("--ide-panel", "#f7f7f7");
    set("--ide-border", "#d0d0d0");
    set("--ide-text", "#333333");
    set("--ide-muted", "#666666");
}

function set(variable, value) {
    document.documentElement.style.setProperty(
        variable,
        value
    );
}
