import { api } from "./api.js";
import { activeTab } from "./state.js";
import { escapeHtml } from "./utils.js";

export async function executeActiveTab() {
    const tab = activeTab();

    if (!tab) return;

    if (!tab.connectionId) {
        showError(
            "This query tab is not associated with a connection."
        );
        return;
    }

    if (!tab.sql.trim()) {
        showError("SQL is empty.");
        return;
    }

    try {
        const result = await api(
            "/api/query/execute",
            {
                method: "POST",
                body: JSON.stringify({
                    tab_id: tab.tabId,
                    connection_id: tab.connectionId,
                    database: tab.database,
                    sql: tab.sql,
                }),
            }
        );

        renderResults(result);
        tab.dirty = false;
    } catch (error) {
        showError(error.message);
    }
}

function renderResults(result) {
    const target = document.querySelector("#results");

    if (!result.columns?.length) {
        target.innerHTML =
            `<div class="p-3">${
                escapeHtml(
                    result.message ||
                    "Command completed."
                )
            }</div>`;
        return;
    }

    let html =
        "<table class='result-table'>" +
        "<thead><tr>";

    for (const column of result.columns) {
        html += `<th>${escapeHtml(column)}</th>`;
    }

    html += "</tr></thead><tbody>";

    for (const row of result.rows) {
        html += "<tr>";

        for (const value of row) {
            html += `<td>${
                escapeHtml(
                    value == null
                        ? "NULL"
                        : value
                )
            }</td>`;
        }

        html += "</tr>";
    }

    html += "</tbody></table>";
    target.innerHTML = html;
}

function showError(message) {
    document.querySelector("#results").innerHTML =
        `<div class="p-3 text-danger">${
            escapeHtml(message)
        }</div>`;
}
