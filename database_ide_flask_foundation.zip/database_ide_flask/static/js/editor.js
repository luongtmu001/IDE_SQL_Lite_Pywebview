import { activeTab } from "./state.js";
import { executeActiveTab } from "./query.js";

export function renderEditor() {
    const tab = activeTab();
    const editor = document.querySelector("#editor");

    if (!tab) {
        editor.innerHTML = "";
        return;
    }

    editor.innerHTML = `
        <textarea
            id="sqlEditor"
            class="sql-editor"
            spellcheck="false"
            placeholder="Write SQL here..."
        ></textarea>
    `;

    const textarea = document.querySelector("#sqlEditor");
    textarea.value = tab.sql;

    textarea.addEventListener("input", () => {
        tab.sql = textarea.value;
        tab.dirty = true;
    });

    textarea.addEventListener("keydown", event => {
        if (
            (event.ctrlKey || event.metaKey)
            && event.key === "Enter"
        ) {
            event.preventDefault();
            executeActiveTab();
        }
    });
}
