import { api } from "./api.js";
import { state } from "./state.js";
import { escapeHtml } from "./utils.js";
import { createTab } from "./tabs.js";

export function renderConnections() {
    const tree =
        document.querySelector(
            "#connectionTree"
        );

    tree.innerHTML =
        state.connections.map(
            connection => `
                <div
                    class="tree-item"
                    data-connection-id="${connection.connection_id}"
                >
                    ▾ ${escapeHtml(connection.type)}
                    —
                    ${escapeHtml(
                        connection.server || ""
                    )}
                </div>

                <div
                    id="db-${connection.connection_id}"
                    class="ms-2"
                ></div>
            `
        ).join("");

    tree.querySelectorAll(
        "[data-connection-id]"
    ).forEach(node => {
        node.addEventListener(
            "click",
            () => loadDatabases(
                node.dataset.connectionId
            )
        );
    });
}

async function loadDatabases(connectionId) {
    try {
        const result = await api(
            `/api/metadata/${connectionId}/databases`
        );

        const container = document.querySelector(
            `#db-${connectionId}`
        );

        container.innerHTML =
            result.items.map(
                database => `
                    <div
                        class="tree-item"
                        data-database="${escapeHtml(
                            database.name
                        )}"
                    >
                        ▸ ${escapeHtml(
                            database.name
                        )}
                    </div>
                `
            ).join("");

        container.querySelectorAll(
            "[data-database]"
        ).forEach(node => {
            node.addEventListener(
                "dblclick",
                () => createTab(
                    connectionId,
                    node.dataset.database
                )
            );
        });
    } catch (error) {
        document.querySelector(
            "#results"
        ).innerHTML =
            `<div class="p-3 text-danger">${
                escapeHtml(error.message)
            }</div>`;
    }
}
